import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { mainServices } from '../../data/navigation';
import { MobileServiceAccordion } from './MobileServiceAccordion';

interface MobileNavProps {
  isOpen: boolean;
  activeService: string | null;
  setActiveService: (service: string | null) => void;
}

export function MobileNav({ isOpen, activeService, setActiveService }: MobileNavProps) {
  if (!isOpen) return null;

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="md:hidden py-4 space-y-4"
    >
      <div className="space-y-4">
        {mainServices.map((service) => (
          <MobileServiceAccordion
            key={service.name}
            service={service}
            isActive={activeService === service.name}
            onToggle={() => setActiveService(activeService === service.name ? null : service.name)}
          />
        ))}
      </div>

      <Link
        to="/work"
        className="block text-white hover:text-indigo-400 transition-colors"
      >
        Work
      </Link>
      <Link
        to="/about"
        className="block text-white hover:text-indigo-400 transition-colors"
      >
        About
      </Link>
      <Link
        to="/quote"
        className="block w-full px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full text-white text-center hover:opacity-90 transition-opacity"
      >
        Request a Quote
      </Link>
    </motion.nav>
  );
}