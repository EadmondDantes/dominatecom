import { motion } from 'framer-motion';
import { useState } from 'react';
import { FaChevronDown } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import { mainServices } from '../../data/navigation';
import { ServicesDropdown } from './ServicesDropdown';

interface DesktopNavProps {
  activeService: string | null;
  setActiveService: (service: string | null) => void;
}

export function DesktopNav({ activeService, setActiveService }: DesktopNavProps) {
  const menuItems = [
    {
      title: 'Services',
      hasDropdown: true
    },
    {
      title: 'Work',
      path: '/work'
    },
    {
      title: 'About',
      path: '/about'
    }
  ];

  return (
    <nav className="hidden md:flex items-center justify-center flex-1">
      <div className="flex items-center space-x-8">
        {menuItems.map((item) => (
          <div
            key={item.title}
            className="relative group"
            onMouseEnter={() => setActiveService(item.hasDropdown ? item.title : null)}
            onMouseLeave={() => setActiveService(null)}
          >
            {item.hasDropdown ? (
              <>
                <button className="flex items-center space-x-1 text-white hover:text-indigo-400 transition-colors">
                  <span>{item.title}</span>
                  <FaChevronDown className="text-sm" />
                </button>
                {activeService === item.title && (
                  <ServicesDropdown 
                    services={mainServices} 
                    onMouseLeave={() => setActiveService(null)} 
                  />
                )}
              </>
            ) : (
              <Link
                to={item.path}
                className="text-white hover:text-indigo-400 transition-colors"
              >
                {item.title}
              </Link>
            )}
          </div>
        ))}
      </div>
    </nav>
  );
}