import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Link } from 'react-router-dom';
import { Breadcrumbs } from '../../components/Breadcrumbs';
import { ParticlesBackground } from '../../components/backgrounds/ParticlesBackground';
import { FaArrowRight } from 'react-icons/fa';

const projects = [
  {
    title: 'Enchant Christmas',
    category: 'Shopify Development',
    image: '/enchant-preview.jpg',
    description: 'A magical e-commerce experience for the worlds largest Christmas light maze.',
    stats: ['200% ROI', '350K Sales', '45% Conversion']
  },
  {
    title: 'Urban Living',
    category: 'Web Design',
    image: '/urban-preview.jpg',
    description: 'Modern real estate development website with interactive features.',
    stats: ['1M+ Revenue', '65% Growth', '4.9 Rating']
  },
  {
    title: 'Beauty Brand',
    category: 'Brand Identity',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9',
    description: 'Complete brand identity redesign for a luxury beauty company.',
    stats: ['90% Retention', '2x AOV', '300k+ Users']
  },
  {
    title: 'Tech Innovators',
    category: 'CRO & Marketing',
    image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661',
    description: 'Conversion optimization and marketing strategy for a tech startup.',
    stats: ['150% Growth', '$2M Sales', '55% ROI']
  }
];

export function WorkPage() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <div className="min-h-screen bg-black pt-20">
      <Breadcrumbs />
      
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <ParticlesBackground />
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/20 to-purple-900/20" />

        <div className="relative container mx-auto px-4 z-10">
          <motion.div
            ref={ref}
            initial={{ y: 50, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-500">
              Our Work
            </h1>
            <p className="text-xl text-gray-400">
              Explore our portfolio of successful projects across web design, branding, and digital marketing.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="relative py-32">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ y: 50, opacity: 0 }}
                animate={inView ? { y: 0, opacity: 1 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 rounded-xl transform group-hover:scale-105 transition-transform duration-300" />
                <div className="relative bg-gray-900/80 backdrop-blur-sm rounded-xl overflow-hidden">
                  <div className="aspect-w-16 aspect-h-9">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="object-cover w-full h-full transform group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60" />
                  </div>
                  <div className="p-8">
                    <span className="inline-block px-3 py-1 bg-indigo-500/30 rounded-full text-sm mb-3">
                      {project.category}
                    </span>
                    <h3 className="text-2xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-400 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.stats.map((stat) => (
                        <span
                          key={stat}
                          className="bg-gradient-to-r from-indigo-600/50 to-purple-600/50 px-3 py-1 rounded-full text-sm"
                        >
                          {stat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="relative py-32">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8 }}
            className="max-w-3xl mx-auto text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-500">
              Start Your Project
            </h2>
            <p className="text-xl text-gray-400">
              Ready to create something amazing together? Let's discuss your project.
            </p>
          </motion.div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-3xl mx-auto"
          >
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 rounded-xl transform group-hover:scale-[1.02] transition-transform duration-300" />
              <div className="relative bg-gray-900/80 backdrop-blur-sm p-8 rounded-xl border border-gray-800">
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Name</label>
                      <input
                        type="text"
                        className="w-full px-4 py-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 transition-colors"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Email</label>
                      <input
                        type="email"
                        className="w-full px-4 py-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 transition-colors"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Project Type</label>
                    <select className="w-full px-4 py-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 transition-colors">
                      <option value="">Select a service</option>
                      <option value="web-design">Web Design</option>
                      <option value="branding">Branding</option>
                      <option value="marketing">Marketing</option>
                      <option value="cro">CRO</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Message</label>
                    <textarea
                      className="w-full px-4 py-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 transition-colors h-32"
                      placeholder="Tell us about your project"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-lg hover:opacity-90 transition-opacity font-semibold"
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}